import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, Laptop, Lock, ChevronRight } from "lucide-react"

export default function PhoneLogin() {
  return (
    <div className="min-h-screen bg-stone-100">
      {/* Header */}
      <div className="p-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center">
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.051 3.706" />
            </svg>
          </div>
          <span className="text-2xl font-light text-gray-700">WhatsApp</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col items-center px-6 pb-6 space-y-6">
        {/* Download Banner */}
        <Card className="w-full max-w-2xl border border-gray-200 shadow-sm">
          <CardContent className="flex items-center justify-between p-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                <Laptop className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Download WhatsApp for Windows</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Make calls, share your screen and get a faster experience when you download the Windows app.
                </p>
              </div>
            </div>
            <Button className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2 rounded-full">
              <Download className="w-4 h-4 mr-2" />
              Download
            </Button>
          </CardContent>
        </Card>

        {/* Phone Number Entry Card */}
        <Card className="w-full max-w-md border border-gray-200 shadow-sm">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-xl font-normal text-gray-800">Enter phone number</CardTitle>
            <p className="text-sm text-gray-600 mt-2">Select a country and enter your phone number.</p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Country Selector */}
            <Select defaultValue="russia">
              <SelectTrigger className="w-full h-12 rounded-full border-gray-300">
                <SelectValue>
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🇷🇺</span>
                    <span>Russia</span>
                  </div>
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="russia">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🇷🇺</span>
                    <span>Russia</span>
                  </div>
                </SelectItem>
                <SelectItem value="usa">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🇺🇸</span>
                    <span>United States</span>
                  </div>
                </SelectItem>
                <SelectItem value="uk">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🇬🇧</span>
                    <span>United Kingdom</span>
                  </div>
                </SelectItem>
                <SelectItem value="india">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🇮🇳</span>
                    <span>India</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>

            {/* Phone Number Input */}
            <Input
              type="tel"
              placeholder="+7"
              defaultValue="+7"
              className="w-full h-12 rounded-full border-gray-300 px-4 text-center"
            />

            {/* Next Button */}
            <div className="flex justify-center pt-4">
              <Button className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-2 rounded-full">Next</Button>
            </div>

            {/* QR Code Login Link */}
            <div className="flex justify-center pt-2">
              <button className="text-gray-600 hover:text-gray-800 text-sm flex items-center gap-1">
                Log in with QR code
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Bottom Links */}
        <div className="text-center space-y-4">
          <p className="text-gray-600">
            {"Don't have a WhatsApp account? "}
            <button className="text-emerald-600 hover:text-emerald-700 underline">Get started</button>
          </p>

          <div className="flex items-center justify-center gap-2 text-gray-500 text-sm">
            <Lock className="w-4 h-4" />
            <span>Your personal messages are end-to-end encrypted</span>
          </div>
        </div>
      </div>
    </div>
  )
}
